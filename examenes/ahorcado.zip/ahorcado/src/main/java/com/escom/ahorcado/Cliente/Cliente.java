/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.escom.ahorcado.Cliente;

import com.escom.ahorcado.Compartidas.Jugador;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.HashMap;

/**
 *
 * @author sandu
 */
public class Cliente {
    private Socket cl;
    private int port;
    private String host;
    private int longitud;
    private int intentos;
    private boolean status;
    private DataOutputStream dos;
    private DataInputStream dis;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    private Jugador usuario;
    private HashMap<Integer,String> respServidor;
    /**
     * 
     * @param host
     * @param port 
     */
    public Cliente(String host, int port){
        this.host = host;
        this.port = port;
        status = false;
        longitud = 0;
        intentos = 4;
        respServidor = new HashMap<>();
        
    }
    
    /**
     * 
     * @param opc se debe ingresar una de tres posibles opciones aceptadas por el servidor
     * 1: Para iniciar el juego y obtener una palabra con base al nivel
     * 2: Para enviar una letra y que el servidor valide si se encuentra en alguna posicion de la palabra
     * 9: Terminar la sesion del cliente
     */
    public void peticion(int opc){
        try {
            dos = new DataOutputStream(cl.getOutputStream());
            dos.writeInt(opc);
            dos.flush();
        } catch (Exception e) {
        }
    }
    
    /**
     * 
     * @return se retorna HashMap que contiene la asociacion entre indices y caracteres
     */
    public HashMap<Integer,String> getMapa(){
        return respServidor;
    }
    
    
    /**
     * Funcion para inicializar el juego. Se envia la peticion 1 al servidor y se envia el objeto serializado Jugador.
     * El servidor enviara como respuesta una longitud correspondiente al nivel del usuario agregado. 
     * @param nivel existen dos posibles niveles, 1: palabras con longitud menor o igual a 5, 2: palabras con longitud mayor a 5
     * @param edad edad del usuario
     * @param nombre nombre de usuario
     * @return se retorna un entero que equivale a la longitud de la palabra que fue elegida por el servidor
     */
    public int iniciar(int nivel, int edad, String nombre){
       usuario = new Jugador(nivel, nombre, edad);
        try {
            //envio de datos de usuario
            peticion(1);
            oos = new ObjectOutputStream(cl.getOutputStream());
            oos.writeObject(usuario);
            oos.flush();
            longitud = dis.readInt();
            for(int i = 0;i<longitud; i++){
                respServidor.put(i,"_");
            }
            return longitud;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }
    
    /**
     * 
     * Funcion para validar si le quedan intentos al usuario
     * @return se retorna un valor booleano correspondiente 
     */
    public boolean quedanIntentos(){
        if(intentos > 0){
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * 
     * @return se retorna el numero de intentos disponibles 
     */
    public int getIntentos(){
        return intentos;
    }
    
    /**
     * 
     * @return se retorna el status del usuario, false aun se encuentra jugando, true ha ganado el juego 
     */
    public boolean checarStatus(){
        return status;
    }
    
    /**
     * Funcion que verifica si la letra seleccionada por el usuario se encuentra dentro de la cadena
     * seleccionada por el servidor.
     * @param letra 
     * @return se retorna un HashMap que contiene la asociacion entre indices y caracteres encontrados
     */
    public HashMap<Integer,String> intento(String letra){
        int [] posiciones = null;
        try {
            //se envia peticion dos que corresponde a validacion
            peticion(2);
            //se envia letra por el stream de datos
            dos.writeUTF(letra);
            dos.flush();
            //Se recibe un objeto (arreglo) que contiene las posiciones donde fue encontrada la letra
            posiciones = (int[])ois.readObject();
            //en caso de no coincidir con alguna letra el servidor retorna un arreglo con el valor -1
            if(posiciones[0] == -1){
                intentos--;
            }else{
                //se actualiza arreglo asociativo con la letra e indices correspondientes
                for(int i = 0; i < posiciones.length; i++){
                    respServidor.put(posiciones[i],letra);
                    System.out.println(posiciones[i]+":"+letra);
                }
            }
            //si el arreglo no cuenta con ningun guion bajo significa que se ha encontrado la palabra completa
            if(!respServidor.containsValue("_")){
                //se actualiza el estatus a ganador
                status = true;
            }
            return respServidor;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return respServidor;
    }
    
    /**
     * Si el usuario desea volver a intentar se hace un reinicio de la palabra y los intentos.
     * @return retorna un entero que corresponde a la longitud de la nueva palabra
     */
    public int restart(){
        try{
            intentos = 4;
            status = false;
            peticion(1);
            oos = new ObjectOutputStream(cl.getOutputStream());
            oos.writeObject(usuario);
            oos.flush();
            longitud = dis.readInt();
            for(int i = 0;i<longitud; i++){
                respServidor.put(i,"_");
            }
            return longitud;                        
        }catch(Exception e){e.printStackTrace();}
        return -1;
    }
    
    /**
     * Funcion para terminar la conexion con el servidor
     */
    public void cerrar(){
        try {
            //se envia la peticion 9 para que el servidor salga del ciclo que se encarga de validar las acciones del usuario
            peticion(9);
            cl.close();
        } catch (Exception e) {
        }
    }
    
    /**
     * Funcion para realizar la conexion con el servidor
     */
    public void conectar(){
        try {
            cl = new Socket(host,port);
            //se inicializan los flujos de datos
            dis = new DataInputStream(cl.getInputStream());
            dos = new DataOutputStream(cl.getOutputStream());
            oos = new ObjectOutputStream(cl.getOutputStream());
            ois = new ObjectInputStream(cl.getInputStream());
        } catch (Exception e) {
        }
    }
    
    
}
