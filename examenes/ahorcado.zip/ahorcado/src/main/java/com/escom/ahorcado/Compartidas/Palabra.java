/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.escom.ahorcado.Compartidas;

import java.io.Serializable;

/**
 *
 * @author sandu
 */
public class Palabra implements Serializable {


    private String texto;
    private int longitud;
    public Palabra(String texto, int longitud){
        this.texto = texto;
        this.longitud = longitud;
    }
    
    /**
     * @return the texto
     */
    public String getTexto() {
        return texto;
    }

    /**
     * @param texto the texto to set
     */
    public void setTexto(String texto) {
        this.texto = texto;
    }

    /**
     * @return the longitud
     */
    public int getLongitud() {
        return longitud;
    }

    /**
     * @param longitud the longitud to set
     */
    public void setLongitud(int longitud) {
        this.longitud = longitud;
    }    
    
    public void mostrarPalabra(){
        System.out.println(this.texto);
    }
}
