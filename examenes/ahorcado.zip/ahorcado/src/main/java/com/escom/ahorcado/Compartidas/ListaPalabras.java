/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.escom.ahorcado.Compartidas;

import java.io.Serializable;
import java.util.LinkedList;

/**
 *
 * @author sandu
 */
public class ListaPalabras implements Serializable {
    private LinkedList<Palabra> palabras;
    
    public ListaPalabras(int[] longitudes, String[] textos){
        palabras = new LinkedList<>();
        //se itera sobre un arreglo de n cadenas y se guardan en la lista de palabras
        for (int i = 0; i<textos.length ; i ++){
            palabras.add(new Palabra(textos[i],longitudes[i]));
        }
    }
    
    public void mostrarLista(){
        for(Palabra p: palabras){
            p.mostrarPalabra();
        }
    }
    
    public Palabra getPalabra(int indice){
        return palabras.get(indice);
    }
}
