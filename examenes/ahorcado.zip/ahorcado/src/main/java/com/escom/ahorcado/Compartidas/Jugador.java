/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.escom.ahorcado.Compartidas;


import java.io.Serializable;

/**
 * Clase serializada de jugador que contiene nivel, nombre y edad
 * @author sandu
 */
public class Jugador implements Serializable {

    private int nivel;
    private String nombre;
    private int edad;

    public Jugador(int nivel,String nombre, int edad) {
        this.nivel = nivel;
        this.nombre = nombre;
        this.edad = edad;
    }

    
    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }    
    
    
    /**
     * @return the nivel
     */
    public int getNivel() {
        return nivel;
    }

    /**
     * @param nivel the nivel to set
     */
    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    /**
     * @return the edad
     */
    public int getEdad() {
        return edad;
    }

    /**
     * @param edad the edad to set
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

}
