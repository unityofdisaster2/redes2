/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.escom.ahorcado.Servidor;

import com.escom.ahorcado.Compartidas.Jugador;
import com.escom.ahorcado.Compartidas.ListaPalabras;
import com.escom.ahorcado.Compartidas.Palabra;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Random;

/**
 *
 * @author sandu
 */
public class Servidor {

    public static void main(String[] args) {
        try {
            ServerSocket s = new ServerSocket(9999);
            //antes de entrar al ciclo se inicializan variables que se van a utilizar varias veces
            ObjectOutputStream oos = null;
            ObjectInputStream ois = null;
            DataInputStream dis = null;
            DataOutputStream dos = null;
            Socket cl;
            boolean lock;
            int peticion;
            Jugador usuario;
            Palabra pal = null;
            //se carga lista de palabras serializadas
            ois = new ObjectInputStream(new FileInputStream("palabras.dat"));
            ListaPalabras lp = (ListaPalabras)ois.readObject();
            Random ran = new Random();
            for(;;){
                cl = s.accept();
                //la variable lock se encargara de controlar si el usuario ya no quiere realizar acciones
                //para que asi el servidor pueda aceptar una nueva conexion
                lock = false;
                System.out.println("cliente conectado desde " + cl.getInetAddress() + ":" + cl.getPort());
                //se obtienen flujos de datos del cliente
                oos = new ObjectOutputStream(cl.getOutputStream());
                dos = new DataOutputStream(cl.getOutputStream());
                ois = new ObjectInputStream(cl.getInputStream());
                dis = new DataInputStream(cl.getInputStream());
                
                while(!lock){
                    peticion = dis.readInt();
                    
                    //peticion 1 corresponde a inicio del juego
                    if(peticion == 1){
                        //se hace lectura de objeto serializado de jugador
                        ois = new ObjectInputStream(cl.getInputStream());
                        usuario = (Jugador)ois.readObject();
                        int aleatorio;
                        //con base en el nivel seleccionado por el usuario
                        //se selecciona una palabra aleatoria de la longitud que le corresponda
                        if(usuario.getNivel()==1){
                            aleatorio = ran.nextInt(19+1);
                            pal = lp.getPalabra(aleatorio);
                            //todo buscar palabras con longitud menor a 5
                        }
                        else if(usuario.getNivel()==2){
                            aleatorio = ran.nextInt(39-20+1)+20;
                            pal = lp.getPalabra(aleatorio);
                            //todo buscar palabras con longitud mayor a 5
                        }
                        //unicamente se envia por el flujo de datos la longitud de la palabra
                        dos.writeInt(pal.getLongitud());
                        dos.flush();
                        System.out.println(pal.getTexto());
                    }
                    //peticion 2 corresponde a intentos
                    if(peticion == 2){
                        //se hace lectura de letra seleccionada por el usuario
                        String letra = dis.readUTF();
                        //se crea lista ligada donde se guardaran de forma dinamica los indices
                        LinkedList <Integer> indices = new LinkedList<>();
                        //se divide la cadena en un arreglo de N letras para asi poder manejar con mas facilidad las posiciones
                        String[] aux = pal.getTexto().split("");
                        int i = 0;
                        for(; i<aux.length; i++){
                            //si el indice corresponde a la letra se guarda
                            if(aux[i].equals(letra)){
                                indices.add(i);
                            }
                        }
                        //si no se encontraron indices se guarda -1
                        if(indices.size()==0){
                            indices.add(-1);
                        }
                        i = 0;
                        //se guarda en un arreglo los indices encontrados
                        int[] envio = new int[indices.size()];
                        
                        for(Integer num:indices){
                            envio[i] = num;
                            i++;
                        }
                       //se envia arreglo con indices a traves del flujo
                        oos.writeObject(envio);
                        oos.flush();
                    }
                    //peticion 9 significa que el usuario ya no quiere realizar mas acciones
                    else if (peticion == 9){
                        lock = true;
                    }
                }
                //Se cierra comunicacion con el cliente para poder aceptar nuevas conexiones
                cl.close();
                dis.close();
                dos.close();
                oos.close();
                ois.close();
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
