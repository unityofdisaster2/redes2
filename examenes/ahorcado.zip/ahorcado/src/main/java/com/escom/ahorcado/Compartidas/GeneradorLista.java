/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.escom.ahorcado.Compartidas;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author sandu
 */
public class GeneradorLista {
    public static void main(String [] args){
        String[] palabras = {"campo","dato","error","etapa","forma","gama","ley",
                            "masa","mayor","menos","nivel","orden","paso","fase",
                            "punto","signo","tubo","tesis","suma","recto","ciencia",
                            "clasificar","coordenadas","diagrama","exactitud",
                            "experimento","hipertrofia","instrumento","investigador",
                            "laboratorio","manual","microscopio","nuclear","problema",
                            "progresivo","sustancia","semejante","temperatura",
                            "trayectoria","transplante"};
        int [] longitudes = new int[palabras.length];
        for(int i = 0; i < palabras.length; i++){
            longitudes[i] = palabras[i].length();
        }
        ListaPalabras lp = new ListaPalabras(longitudes, palabras);
        try{
            //se crea flujo de datos para guardar el objeto lp en un archivo
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("palabras.dat"));
            oos.writeObject(lp);
            /*
            System.out.println("recuperando...");
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("palabras.dat"));
            lp = (ListaPalabras)ois.readObject();
            lp.mostrarLista();
            */
            
        }catch(Exception e){}

    }
}
